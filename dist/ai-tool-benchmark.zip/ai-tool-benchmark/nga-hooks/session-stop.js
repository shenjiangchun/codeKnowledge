// Re-exports the generic adapter under the nga event name "session.stop".
// If your nga build doesn't emit this event, simply don't register this file.
module.exports = require("./_adapter.js");
