// Re-exports the generic adapter under the nga event name "chat.message".
// Filename → event mapping is automatic (kebab-case → dot-case) inside _adapter.js.
module.exports = require("./_adapter.js");
