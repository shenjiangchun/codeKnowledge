// AI Tool Benchmark — generic hook adapter for CodeAgent CLI (nga)
//
// One file is reused for every nga hook event by symlink/copy with different filenames:
//   chat-message.js              -> nga event "chat.message"
//   tool-execute-before.js       -> nga event "tool.execute.before"
//   tool-execute-after.js        -> nga event "tool.execute.after"
//
// The event name is derived from BENCH_EVENT env var (set by install script)
// or from the filename (kebab-case → dot-case).
//
// What it does:
//   When nga fires the event, this hook spawns:
//        python <BENCH_PY> hook <EventName>
//   and pipes a JSON payload (the hook context) to its stdin.
//   bench.py appends one event line to the active session's events.jsonl.
//
// Failure mode: if bench.py is missing OR no active session is running,
// the hook silently returns — it never blocks nga's normal flow.

const { spawn } = require("child_process");
const path = require("path");

// === CONFIG (override via env vars) ==========================================
const BENCH_PY =
  process.env.BENCH_PY ||
  path.join(
    process.env.USERPROFILE || process.env.HOME,
    ".claude", "skills", "ai-tool-benchmark", "bench.py"
  );
const PYTHON = process.env.BENCH_PYTHON || "python";

// Derive event name: BENCH_EVENT > filename
function deriveEvent() {
  if (process.env.BENCH_EVENT) return process.env.BENCH_EVENT;
  const base = path.basename(__filename, path.extname(__filename));   // e.g. "tool-execute-before"
  return base.replace(/-/g, ".");                                      // → "tool.execute.before"
}

function forward(payload) {
  return new Promise((resolve) => {
    let proc;
    try {
      proc = spawn(PYTHON, [BENCH_PY, "hook", deriveEvent()], {
        stdio: ["pipe", "ignore", "ignore"],
        windowsHide: true,
      });
    } catch (e) {
      return resolve();   // never crash nga
    }
    proc.on("error", () => resolve());
    proc.on("exit",  () => resolve());
    try {
      proc.stdin.write(JSON.stringify(payload || {}));
      proc.stdin.end();
    } catch (_) { /* ignore */ }
  });
}

// === nga hook export =========================================================
// The exact signature depends on nga's plugin contract. The most common pattern
// is `module.exports = async (ctx) => { ... return ctx; }`. We accept anything
// passed in, forward it, and return it untouched so nga's pipeline keeps going.
module.exports = async function (ctx) {
  await forward(ctx);
  return ctx;
};

// Some plugin systems expect a named handler — expose both for safety.
module.exports.handler = module.exports;
module.exports.default = module.exports;
