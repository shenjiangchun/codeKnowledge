// Re-exports the generic adapter under the nga event name "tool.execute.before".
module.exports = require("./_adapter.js");
