// Re-exports the generic adapter under the nga event name "tool.execute.after".
module.exports = require("./_adapter.js");
